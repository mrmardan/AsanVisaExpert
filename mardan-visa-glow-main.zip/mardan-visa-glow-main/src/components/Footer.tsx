
import { Separator } from "@/components/ui/separator";
import { Facebook, Instagram, Twitter, Linkedin, Phone, Mail, MapPin } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="bg-gradient-to-r from-gray-900 to-gray-800 text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
              Asan Visa Consultancy
            </h3>
            <p className="text-gray-300 leading-relaxed">
              Your trusted partner for visa and immigration services in Mardan. We help make your international dreams come true.
            </p>
            <div className="flex space-x-4">
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors cursor-pointer">
                <Facebook className="h-5 w-5" />
              </div>
              <div className="w-10 h-10 bg-pink-600 rounded-full flex items-center justify-center hover:bg-pink-700 transition-colors cursor-pointer">
                <Instagram className="h-5 w-5" />
              </div>
              <div className="w-10 h-10 bg-blue-400 rounded-full flex items-center justify-center hover:bg-blue-500 transition-colors cursor-pointer">
                <Twitter className="h-5 w-5" />
              </div>
              <div className="w-10 h-10 bg-blue-800 rounded-full flex items-center justify-center hover:bg-blue-900 transition-colors cursor-pointer">
                <Linkedin className="h-5 w-5" />
              </div>
            </div>
          </div>
          
          {/* Services */}
          <div className="space-y-6">
            <h4 className="text-xl font-semibold">Our Services</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">Tourist Visa</a></li>
              <li><a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">Student Visa</a></li>
              <li><a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">Work Visa</a></li>
              <li><a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">Family Visa</a></li>
              <li><a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">Immigration</a></li>
              <li><a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">Documentation</a></li>
            </ul>
          </div>
          
          {/* Quick Links */}
          <div className="space-y-6">
            <h4 className="text-xl font-semibold">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">About Us</a></li>
              <li><a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">Success Stories</a></li>
              <li><a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">Blog</a></li>
              <li><a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">FAQ</a></li>
              <li><a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-300 hover:text-yellow-400 transition-colors">Terms of Service</a></li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div className="space-y-6">
            <h4 className="text-xl font-semibold">Contact Info</h4>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-yellow-400" />
                <span className="text-gray-300">Main Bazaar, Near City Plaza, Mardan, KPK</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-yellow-400" />
                <span className="text-gray-300">03459353343 (WhatsApp)</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-yellow-400" />
                <span className="text-gray-300">Mr.mardan@gmail.com</span>
              </div>
            </div>
          </div>
        </div>
        
        <Separator className="my-8 bg-gray-600" />
        
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-gray-400 text-center md:text-left">
            © 2024 Asan Visa Consultancy Expert Mardan. All rights reserved.
          </p>
          <p className="text-gray-400 text-center md:text-right">
            Made with ❤️ for your visa success
          </p>
        </div>
      </div>
    </footer>
  );
};
