
import { Button } from "@/components/ui/button";
import { ArrowRight, Globe, Shield, Users, Star, Award, CheckCircle } from "lucide-react";
import { VisaSlider } from "./VisaSlider";
import { TravelAnimation } from "./TravelAnimation";

export const Hero = () => {
  return (
    <section className="relative min-h-screen flex flex-col justify-center bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 overflow-hidden">
      {/* Enhanced Background decoration */}
      <div className="absolute inset-0 bg-black/20"></div>
      <div className="absolute top-20 left-20 w-72 h-72 bg-gradient-to-r from-yellow-400/20 to-orange-400/20 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-20 w-96 h-96 bg-gradient-to-r from-blue-400/20 to-purple-400/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-gradient-to-r from-green-400/10 to-blue-400/10 rounded-full blur-3xl animate-spin-slow"></div>
      
      <div className="container mx-auto px-4 z-10 space-y-16">
        {/* Header Section */}
        <div className="text-center text-white max-w-4xl mx-auto">
          {/* Animated main heading with shadow */}
          <h1 className="text-5xl md:text-7xl font-bold mb-6" style={{ textShadow: '0 4px 8px rgba(0, 0, 0, 0.5), 0 2px 4px rgba(0, 0, 0, 0.3)' }}>
            <span className="inline-block animate-[fadeInUp_1s_ease-out] bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent" style={{ textShadow: '0 4px 8px rgba(251, 191, 36, 0.3), 0 2px 4px rgba(251, 191, 36, 0.2)' }}>
              Asan Visa
            </span>
            <br />
            <span className="inline-block animate-[fadeInUp_1s_ease-out_0.3s_both] text-white transform hover:scale-105 transition-transform duration-300">
              Consultancy Expert
            </span>
            <br />
            <span className="inline-block animate-[fadeInUp_1s_ease-out_0.6s_both] text-2xl md:text-3xl font-medium text-blue-200 hover:text-yellow-400 transition-colors duration-500">
              Mardan
            </span>
          </h1>
          
          {/* Enhanced subtitle with badges */}
          <div className="flex flex-wrap justify-center gap-4 mb-6 animate-fade-in delay-700">
            <div className="flex items-center bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 hover:bg-white/20 transition-all duration-300 hover:scale-105">
              <Award className="h-5 w-5 mr-2 text-yellow-400" />
              <span className="text-sm font-medium">Licensed Consultancy</span>
            </div>
            <div className="flex items-center bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 hover:bg-white/20 transition-all duration-300 hover:scale-105">
              <Star className="h-5 w-5 mr-2 text-yellow-400" />
              <span className="text-sm font-medium">5-Star Rated</span>
            </div>
            <div className="flex items-center bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 hover:bg-white/20 transition-all duration-300 hover:scale-105">
              <CheckCircle className="h-5 w-5 mr-2 text-green-400" />
              <span className="text-sm font-medium">Trusted Partner</span>
            </div>
          </div>
          
          <p className="text-xl md:text-2xl mb-8 text-blue-100 animate-fade-in delay-1000">
            Your Gateway to Global Opportunities
          </p>
          
          {/* Description */}
          <p className="text-lg mb-12 text-blue-200 max-w-2xl mx-auto animate-fade-in delay-1000">
            Expert visa consultancy services with years of experience helping clients achieve their dreams of traveling, studying, and working abroad.
          </p>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16 animate-fade-in delay-1000">
            <Button size="lg" className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white font-semibold px-8 py-4 text-lg group shadow-2xl">
              Get Free Consultation
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-900 font-semibold px-8 py-4 text-lg shadow-xl">
              View Our Services
            </Button>
          </div>
        </div>

        {/* Visa Services Slider */}
        <div className="animate-fade-in delay-1000">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Our Visa Services
            </h2>
            <p className="text-blue-200 text-lg max-w-2xl mx-auto">
              Discover our comprehensive range of visa services tailored to your needs
            </p>
          </div>
          <VisaSlider />
        </div>

        {/* Travel Animation */}
        <div className="animate-fade-in delay-1000">
          <TravelAnimation />
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 animate-fade-in delay-1000">
          <div className="text-center bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
            <div className="flex justify-center mb-4">
              <Users className="h-12 w-12 text-yellow-400" />
            </div>
            <div className="text-3xl font-bold mb-2">1000+</div>
            <div className="text-blue-200">Happy Clients</div>
          </div>
          <div className="text-center bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
            <div className="flex justify-center mb-4">
              <Globe className="h-12 w-12 text-yellow-400" />
            </div>
            <div className="text-3xl font-bold mb-2">25+</div>
            <div className="text-blue-200">Countries</div>
          </div>
          <div className="text-center bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
            <div className="flex justify-center mb-4">
              <Shield className="h-12 w-12 text-yellow-400" />
            </div>
            <div className="text-3xl font-bold mb-2">98%</div>
            <div className="text-blue-200">Success Rate</div>
          </div>
        </div>
      </div>
    </section>
  );
};
