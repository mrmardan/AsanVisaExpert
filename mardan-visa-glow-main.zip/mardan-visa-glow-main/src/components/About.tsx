
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Award, Clock, Users, CheckCircle } from "lucide-react";

export const About = () => {
  return (
    <section className="py-20 bg-gradient-to-br from-blue-900 via-indigo-900 to-purple-900">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div className="text-white">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Why Choose{" "}
              <span className="bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
                Asan Visa
              </span>
              ?
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              With years of expertise in visa consultancy, we have successfully helped thousands of clients achieve their international dreams.
            </p>
            
            <div className="space-y-6 mb-8">
              <div className="flex items-start space-x-4">
                <CheckCircle className="h-6 w-6 text-yellow-400 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-lg mb-2">Expert Guidance</h3>
                  <p className="text-blue-200">Professional consultants with in-depth knowledge of immigration laws</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <CheckCircle className="h-6 w-6 text-yellow-400 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-lg mb-2">Personalized Service</h3>
                  <p className="text-blue-200">Tailored solutions based on your specific needs and circumstances</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <CheckCircle className="h-6 w-6 text-yellow-400 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-lg mb-2">End-to-End Support</h3>
                  <p className="text-blue-200">Complete assistance from application to visa approval</p>
                </div>
              </div>
            </div>
            
            <Button size="lg" className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white font-semibold px-8 py-4">
              Learn More About Us
            </Button>
          </div>
          
          {/* Right Content - Stats Cards */}
          <div className="grid grid-cols-2 gap-6">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white text-center p-6 hover:bg-white/20 transition-all duration-300">
              <CardContent className="space-y-4">
                <Award className="h-12 w-12 text-yellow-400 mx-auto" />
                <div className="text-3xl font-bold">10+</div>
                <div className="text-blue-200">Years Experience</div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white text-center p-6 hover:bg-white/20 transition-all duration-300">
              <CardContent className="space-y-4">
                <Users className="h-12 w-12 text-yellow-400 mx-auto" />
                <div className="text-3xl font-bold">1000+</div>
                <div className="text-blue-200">Success Stories</div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white text-center p-6 hover:bg-white/20 transition-all duration-300">
              <CardContent className="space-y-4">
                <Clock className="h-12 w-12 text-yellow-400 mx-auto" />
                <div className="text-3xl font-bold">24/7</div>
                <div className="text-blue-200">Support Available</div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white text-center p-6 hover:bg-white/20 transition-all duration-300">
              <CardContent className="space-y-4">
                <CheckCircle className="h-12 w-12 text-yellow-400 mx-auto" />
                <div className="text-3xl font-bold">98%</div>
                <div className="text-blue-200">Approval Rate</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};
