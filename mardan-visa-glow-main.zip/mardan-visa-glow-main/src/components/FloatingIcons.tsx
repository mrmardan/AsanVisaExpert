
import React from 'react';
import { Plane, Map, Tickets, Rocket, Ship, Train } from 'lucide-react';

export const FloatingIcons = () => {
  const icons = [
    { Icon: Plane, delay: '0s', position: 'top-10 left-10' },
    { Icon: Map, delay: '2s', position: 'top-20 right-16' },
    { Icon: Tickets, delay: '4s', position: 'bottom-20 left-16' },
    { Icon: Rocket, delay: '1s', position: 'top-1/2 right-8' },
    { Icon: Ship, delay: '3s', position: 'bottom-16 right-20' },
    { Icon: Train, delay: '5s', position: 'top-16 left-1/3' },
  ];

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {icons.map(({ Icon, delay, position }, index) => (
        <div
          key={index}
          className={`absolute ${position} animate-[float_6s_ease-in-out_infinite] opacity-10`}
          style={{ animationDelay: delay }}
        >
          <Icon className="h-8 w-8 text-blue-500" />
        </div>
      ))}
    </div>
  );
};
