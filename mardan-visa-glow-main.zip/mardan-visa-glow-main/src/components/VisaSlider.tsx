import React from 'react';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plane, GraduationCap, Briefcase, Heart, MapPin, Clock } from "lucide-react";

const visaTypes = [
  {
    id: 1,
    title: "Tourist Visa",
    description: "Explore the world with our comprehensive tourist visa services",
    icon: Plane,
    image: "https://images.unsplash.com/photo-1488646953014-85cb44e25828?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    features: ["Quick Processing", "90% Success Rate", "Multiple Entry Options"],
    countries: "150+ Countries"
  },
  {
    id: 2,
    title: "Student Visa",
    description: "Pursue your academic dreams with our student visa expertise",
    icon: GraduationCap,
    image: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    features: ["University Selection", "Document Prep", "Interview Training"],
    countries: "25+ Countries"
  },
  {
    id: 3,
    title: "Work Visa",
    description: "Build your career abroad with our work visa solutions",
    icon: Briefcase,
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    features: ["Job Placement", "Skills Assessment", "Fast Track Process"],
    countries: "30+ Countries"
  },
  {
    id: 4,
    title: "Family Visa",
    description: "Reunite with your loved ones through family visa programs",
    icon: Heart,
    image: "https://images.unsplash.com/photo-1517022812141-23620dba5c23?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    features: ["Spouse Visa", "Dependent Visa", "Parent Visa"],
    countries: "40+ Countries"
  }
];

export const VisaSlider = () => {
  return (
    <div className="w-full max-w-6xl mx-auto px-4">
      <Carousel className="w-full" opts={{ align: "start", loop: true }}>
        <CarouselContent>
          {visaTypes.map((visa) => {
            const IconComponent = visa.icon;
            return (
              <CarouselItem key={visa.id} className="md:basis-1/2 lg:basis-1/3">
                <div className="p-2">
                  <Card className="overflow-hidden bg-white/95 backdrop-blur-sm border-none shadow-2xl hover:shadow-3xl transition-all duration-300 hover:scale-105">
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={visa.image} 
                        alt={visa.title}
                        className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                      <div className="absolute top-4 right-4 bg-white/90 p-2 rounded-full">
                        <IconComponent className="h-6 w-6 text-blue-600" />
                      </div>
                      <div className="absolute bottom-4 left-4 flex items-center text-white">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span className="text-sm font-medium">{visa.countries}</span>
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <h3 className="text-xl font-bold text-gray-800 mb-2">{visa.title}</h3>
                      <p className="text-gray-600 mb-4 text-sm">{visa.description}</p>
                      <div className="space-y-2 mb-4">
                        {visa.features.map((feature, index) => (
                          <div key={index} className="flex items-center text-sm text-gray-600">
                            <Clock className="h-3 w-3 mr-2 text-green-500" />
                            {feature}
                          </div>
                        ))}
                      </div>
                      <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white">
                        Learn More
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </CarouselItem>
            );
          })}
        </CarouselContent>
        <CarouselPrevious className="left-4 bg-white/80 border-none hover:bg-white" />
        <CarouselNext className="right-4 bg-white/80 border-none hover:bg-white" />
      </Carousel>
    </div>
  );
};
