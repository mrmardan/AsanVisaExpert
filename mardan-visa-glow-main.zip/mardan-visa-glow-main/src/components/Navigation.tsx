
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { name: "Home", path: "/" },
    { name: "About", path: "/about" },
    { name: "Services", path: "/services" },
    { name: "Success Stories", path: "/success-stories" },
    { name: "FAQ", path: "/faq" },
    { name: "Contact", path: "/contact" },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-white/95 backdrop-blur-sm shadow-lg fixed top-0 left-0 right-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <div className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent animate-[fadeInUp_1s_ease-out]" style={{ textShadow: '0 2px 4px rgba(59, 130, 246, 0.3)' }}>
              Asan Visa
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item, index) => (
              <Link
                key={item.name}
                to={item.path}
                className={`font-medium transition-all duration-300 hover:text-blue-600 transform hover:scale-105 animate-[fadeInUp_1s_ease-out] ${
                  isActive(item.path) ? "text-blue-600" : "text-gray-700"
                }`}
                style={{ 
                  animationDelay: `${0.1 + index * 0.1}s`,
                  animationFillMode: 'both',
                  textShadow: isActive(item.path) ? '0 2px 4px rgba(59, 130, 246, 0.2)' : '0 1px 2px rgba(0, 0, 0, 0.1)'
                }}
              >
                {item.name}
              </Link>
            ))}
            <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 animate-[fadeInUp_1s_ease-out] transform hover:scale-105 transition-all duration-300 shadow-lg" style={{ animationDelay: '0.8s', animationFillMode: 'both' }}>
              Free Consultation
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden animate-[fadeInUp_1s_ease-out]"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            style={{ animationDelay: '0.5s', animationFillMode: 'both' }}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t animate-[fadeInUp_0.3s_ease-out]">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navItems.map((item, index) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`block px-3 py-2 text-base font-medium transition-all duration-300 hover:text-blue-600 transform hover:scale-105 animate-[fadeInUp_0.5s_ease-out] ${
                    isActive(item.path) ? "text-blue-600" : "text-gray-700"
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                  style={{ 
                    animationDelay: `${0.1 + index * 0.05}s`,
                    animationFillMode: 'both',
                    textShadow: isActive(item.path) ? '0 2px 4px rgba(59, 130, 246, 0.2)' : '0 1px 2px rgba(0, 0, 0, 0.1)'
                  }}
                >
                  {item.name}
                </Link>
              ))}
              <div className="px-3 py-2 animate-[fadeInUp_0.5s_ease-out]" style={{ animationDelay: '0.4s', animationFillMode: 'both' }}>
                <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transform hover:scale-105 transition-all duration-300 shadow-lg">
                  Free Consultation
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};
