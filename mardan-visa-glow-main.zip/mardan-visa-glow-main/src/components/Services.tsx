
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Plane, GraduationCap, Briefcase, Heart, MapPin, FileText } from "lucide-react";
import { TravelAnimation } from "./TravelAnimation";

const services = [
  {
    icon: Plane,
    title: "Tourist Visa",
    description: "Complete assistance for tourist and visit visas to explore the world",
    features: ["Document preparation", "Application filing", "Interview guidance"]
  },
  {
    icon: GraduationCap,
    title: "Student Visa",
    description: "Expert guidance for study abroad programs and student visas",
    features: ["University selection", "Scholarship guidance", "Visa processing"]
  },
  {
    icon: Briefcase,
    title: "Work Visa",
    description: "Professional support for work permits and employment visas",
    features: ["Job placement", "Work permit", "Family visa assistance"]
  },
  {
    icon: Heart,
    title: "Family Visa",
    description: "Reunite with your loved ones through family sponsorship programs",
    features: ["Spouse visa", "Dependent visa", "Parent sponsorship"]
  },
  {
    icon: MapPin,
    title: "Immigration",
    description: "Permanent residency and immigration consultation services",
    features: ["PR applications", "Citizenship guidance", "Investment visa"]
  },
  {
    icon: FileText,
    title: "Documentation",
    description: "Complete document verification and attestation services",
    features: ["Document verification", "Attestation services", "Translation"]
  }
];

export const Services = () => {
  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-900 to-indigo-900 bg-clip-text text-transparent">
            Our Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive visa and immigration services tailored to your specific needs
          </p>
        </div>
        
        {/* Travel Animation */}
        <TravelAnimation />
        
        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-0 shadow-lg bg-white/80 backdrop-blur-sm animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
              <CardHeader className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center group-hover:scale-110 group-hover:rotate-12 transition-all duration-300">
                    <service.icon className="h-8 w-8 text-white" />
                  </div>
                </div>
                <CardTitle className="text-xl font-bold text-gray-900">{service.title}</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <CardDescription className="text-gray-600 mb-6 text-base">
                  {service.description}
                </CardDescription>
                <ul className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="text-sm text-gray-500 flex items-center justify-center group-hover:text-gray-700 transition-colors duration-300">
                      <div className="w-2 h-2 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full mr-2 group-hover:scale-125 transition-transform duration-300"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
