
import React from 'react';
import { Plane, MapPin, Route, Luggage } from 'lucide-react';

export const TravelAnimation = () => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg p-8 my-8">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Flying Plane */}
        <div className="absolute top-4 animate-[slide-right_15s_ease-in-out_infinite]">
          <Plane className="h-8 w-8 text-blue-500 rotate-45" />
        </div>
        
        {/* Moving Map Pins */}
        <div className="absolute top-12 left-1/4 animate-pulse">
          <MapPin className="h-6 w-6 text-red-500" />
        </div>
        <div className="absolute top-8 right-1/3 animate-pulse delay-500">
          <MapPin className="h-6 w-6 text-green-500" />
        </div>
        <div className="absolute bottom-8 left-1/3 animate-pulse delay-1000">
          <MapPin className="h-6 w-6 text-purple-500" />
        </div>
        
        {/* Floating Route Lines */}
        <div className="absolute top-6 right-1/4 animate-bounce delay-300">
          <Route className="h-5 w-5 text-blue-400" />
        </div>
        
        {/* Luggage Icons */}
        <div className="absolute bottom-4 right-8 animate-[float_3s_ease-in-out_infinite]">
          <Luggage className="h-6 w-6 text-orange-500" />
        </div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 text-center">
        <h3 className="text-2xl font-bold text-gray-800 mb-2">Your Journey Starts Here</h3>
        <p className="text-gray-600">Let us guide you to your dream destination</p>
      </div>
    </div>
  );
};
