
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Award, Users, Globe, CheckCircle, Target, Heart } from "lucide-react";

const AboutPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-16">
        {/* Header Section */}
        <section className="py-20 bg-gradient-to-br from-blue-900 via-indigo-900 to-purple-900">
          <div className="container mx-auto px-4">
            <div className="text-center text-white max-w-4xl mx-auto">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                About <span className="bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">Asan Visa</span>
              </h1>
              <p className="text-xl text-blue-100">
                Your trusted partner in making international dreams come true through expert visa consultancy services.
              </p>
            </div>
          </div>
        </section>

        {/* Our Story Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="text-4xl font-bold mb-6 text-gray-900">Our Story</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Established in Mardan, Asan Visa Consultancy Expert has been helping individuals and families achieve their international dreams for over a decade. What started as a small consultancy firm has grown into one of the most trusted visa service providers in the region.
                </p>
                <p className="text-lg text-gray-600 mb-6">
                  Our journey began with a simple mission: to make visa processes accessible, transparent, and successful for everyone. We understand that each client's situation is unique, and we pride ourselves on providing personalized solutions that fit individual needs and circumstances.
                </p>
                <p className="text-lg text-gray-600">
                  Today, we continue to uphold our commitment to excellence, maintaining a success rate of over 98% and helping thousands of clients worldwide.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-6">
                <Card className="text-center p-6 shadow-lg">
                  <CardContent className="space-y-4">
                    <Award className="h-12 w-12 text-blue-600 mx-auto" />
                    <div className="text-3xl font-bold text-gray-900">10+</div>
                    <div className="text-gray-600">Years Experience</div>
                  </CardContent>
                </Card>
                <Card className="text-center p-6 shadow-lg">
                  <CardContent className="space-y-4">
                    <Users className="h-12 w-12 text-green-600 mx-auto" />
                    <div className="text-3xl font-bold text-gray-900">1000+</div>
                    <div className="text-gray-600">Happy Clients</div>
                  </CardContent>
                </Card>
                <Card className="text-center p-6 shadow-lg">
                  <CardContent className="space-y-4">
                    <Globe className="h-12 w-12 text-purple-600 mx-auto" />
                    <div className="text-3xl font-bold text-gray-900">25+</div>
                    <div className="text-gray-600">Countries</div>
                  </CardContent>
                </Card>
                <Card className="text-center p-6 shadow-lg">
                  <CardContent className="space-y-4">
                    <CheckCircle className="h-12 w-12 text-yellow-600 mx-auto" />
                    <div className="text-3xl font-bold text-gray-900">98%</div>
                    <div className="text-gray-600">Success Rate</div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Mission & Vision Section */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-6 text-gray-900">Mission & Vision</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <Card className="shadow-xl border-0 p-8">
                <CardContent className="text-center space-y-6">
                  <Target className="h-16 w-16 text-blue-600 mx-auto" />
                  <h3 className="text-2xl font-bold text-gray-900">Our Mission</h3>
                  <p className="text-gray-600 text-lg">
                    To provide exceptional visa consultancy services that simplify the immigration process, ensuring our clients achieve their international goals with confidence and peace of mind.
                  </p>
                </CardContent>
              </Card>
              <Card className="shadow-xl border-0 p-8">
                <CardContent className="text-center space-y-6">
                  <Heart className="h-16 w-16 text-red-600 mx-auto" />
                  <h3 className="text-2xl font-bold text-gray-900">Our Vision</h3>
                  <p className="text-gray-600 text-lg">
                    To be the leading visa consultancy firm, recognized for our integrity, expertise, and commitment to helping people connect with opportunities around the world.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Why Choose Us Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-6 text-gray-900">Why Choose Asan Visa?</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                We stand out from the competition through our commitment to excellence and personalized service.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  title: "Expert Guidance",
                  description: "Professional consultants with in-depth knowledge of immigration laws and procedures."
                },
                {
                  title: "Personalized Service",
                  description: "Tailored solutions based on your specific needs, background, and circumstances."
                },
                {
                  title: "High Success Rate",
                  description: "Over 98% success rate with thousands of satisfied clients worldwide."
                },
                {
                  title: "Transparent Process",
                  description: "Clear communication and honest advice throughout your visa application journey."
                },
                {
                  title: "End-to-End Support",
                  description: "Complete assistance from initial consultation to visa approval and beyond."
                },
                {
                  title: "Affordable Pricing",
                  description: "Competitive rates with no hidden fees or surprise charges."
                }
              ].map((feature, index) => (
                <Card key={index} className="shadow-lg border-0 hover:shadow-xl transition-shadow duration-300">
                  <CardContent className="p-6 text-center space-y-4">
                    <CheckCircle className="h-12 w-12 text-green-600 mx-auto" />
                    <h3 className="text-xl font-bold text-gray-900">{feature.title}</h3>
                    <p className="text-gray-600">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </div>
  );
};

export default AboutPage;
