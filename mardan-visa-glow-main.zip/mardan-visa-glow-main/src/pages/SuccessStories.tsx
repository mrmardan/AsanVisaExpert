
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Star, MapPin } from "lucide-react";

const SuccessStories = () => {
  const testimonials = [
    {
      name: "Ahmed Khan",
      country: "Canada",
      visaType: "Student Visa",
      story: "Asan Visa made my dream of studying in Canada come true. Their expert guidance helped me secure admission to the University of Toronto and get my student visa approved within 6 weeks.",
      rating: 5,
      image: "/placeholder.svg"
    },
    {
      name: "Sarah Ali",
      country: "Australia",
      visaType: "Work Visa",
      story: "I was struggling with my work visa application for months. Asan Visa team took over and within 8 weeks, I had my visa approved. Now I'm working as a software engineer in Sydney!",
      rating: 5,
      image: "/placeholder.svg"
    },
    {
      name: "Muhammad Hassan",
      country: "UK",
      visaType: "Family Visa",
      story: "After 2 years of separation, Asan Visa helped reunite me with my family in London. Their professional approach and attention to detail made all the difference.",
      rating: 5,
      image: "/placeholder.svg"
    },
    {
      name: "Fatima Sheikh",
      country: "USA",
      visaType: "Tourist Visa",
      story: "I was denied a US tourist visa twice before coming to Asan Visa. They helped me understand what was missing and guided me to a successful application on the third attempt.",
      rating: 5,
      image: "/placeholder.svg"
    },
    {
      name: "Bilal Ahmed",
      country: "Germany",
      visaType: "Student Visa",
      story: "Studying in Germany seemed impossible until I met the Asan Visa team. They helped me with university applications, scholarships, and visa processing. Highly recommended!",
      rating: 5,
      image: "/placeholder.svg"
    },
    {
      name: "Aisha Malik",
      country: "New Zealand",
      visaType: "Immigration",
      story: "Our family's permanent residency application to New Zealand was handled professionally by Asan Visa. We're now proud residents of Auckland thanks to their expertise.",
      rating: 5,
      image: "/placeholder.svg"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-16">
        {/* Header Section */}
        <section className="py-20 bg-gradient-to-br from-blue-900 via-indigo-900 to-purple-900">
          <div className="container mx-auto px-4">
            <div className="text-center text-white max-w-4xl mx-auto">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Success <span className="bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">Stories</span>
              </h1>
              <p className="text-xl text-blue-100">
                Real stories from real people who achieved their international dreams with our help.
              </p>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
              <div>
                <div className="text-4xl font-bold text-blue-600 mb-2">1000+</div>
                <div className="text-gray-600">Happy Clients</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-green-600 mb-2">98%</div>
                <div className="text-gray-600">Success Rate</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-purple-600 mb-2">25+</div>
                <div className="text-gray-600">Countries</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-orange-600 mb-2">10+</div>
                <div className="text-gray-600">Years Experience</div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-6 text-gray-900">What Our Clients Say</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Read testimonials from clients who successfully achieved their visa goals with our assistance.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <Card key={index} className="shadow-lg border-0 hover:shadow-xl transition-shadow duration-300">
                  <CardContent className="p-6 space-y-4">
                    <div className="flex items-center space-x-1 mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    
                    <p className="text-gray-600 italic">"{testimonial.story}"</p>
                    
                    <div className="border-t pt-4">
                      <div className="font-semibold text-gray-900">{testimonial.name}</div>
                      <div className="flex items-center text-sm text-gray-500 mt-1">
                        <MapPin className="h-4 w-4 mr-1" />
                        {testimonial.country} • {testimonial.visaType}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-600">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl font-bold text-white mb-6">Ready to Write Your Success Story?</h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Join thousands of satisfied clients who have achieved their international dreams with our expert guidance.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-white text-blue-600 font-semibold px-8 py-4 rounded-lg hover:bg-gray-100 transition-colors">
                Free Consultation
              </button>
              <button className="border-2 border-white text-white font-semibold px-8 py-4 rounded-lg hover:bg-white hover:text-blue-600 transition-colors">
                Contact Us Today
              </button>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </div>
  );
};

export default SuccessStories;
