
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";

const FAQ = () => {
  const [openItem, setOpenItem] = useState<number | null>(null);

  const faqs = [
    {
      category: "General Questions",
      questions: [
        {
          question: "What services does Asan Visa Consultancy provide?",
          answer: "We provide comprehensive visa and immigration services including tourist visas, student visas, work visas, family visas, permanent residency applications, and document attestation services for over 25 countries."
        },
        {
          question: "How long does the visa process typically take?",
          answer: "Processing times vary by country and visa type. Tourist visas typically take 2-4 weeks, student visas 4-8 weeks, and work/immigration visas can take 3-12 months. We provide realistic timelines during your consultation."
        },
        {
          question: "What is your success rate?",
          answer: "We maintain a 98% success rate across all visa types. Our experienced team ensures proper documentation and preparation to maximize your chances of approval."
        }
      ]
    },
    {
      category: "Student Visas",
      questions: [
        {
          question: "Can you help me choose the right university?",
          answer: "Yes! We provide university selection guidance based on your academic background, budget, and career goals. We have partnerships with universities in USA, UK, Canada, Australia, and other popular study destinations."
        },
        {
          question: "Do you assist with scholarship applications?",
          answer: "Absolutely. We help identify scholarship opportunities and assist with scholarship applications to reduce your financial burden for international education."
        },
        {
          question: "What documents are required for a student visa?",
          answer: "Common documents include academic transcripts, English proficiency test scores (IELTS/TOEFL), statement of purpose, financial statements, passport, and university acceptance letter. Requirements vary by country."
        }
      ]
    },
    {
      category: "Work Visas",
      questions: [
        {
          question: "Can you help me find a job abroad?",
          answer: "Yes, we have connections with employers in various countries and can assist with job placement services, especially for skilled professionals in IT, healthcare, engineering, and other in-demand fields."
        },
        {
          question: "What is the difference between a work permit and work visa?",
          answer: "A work permit is authorization to work in a country, while a work visa allows entry into the country. Often, you need both. We handle the entire process for you."
        },
        {
          question: "Can my family accompany me on a work visa?",
          answer: "Most countries allow dependents (spouse and children) to accompany work visa holders. We assist with dependent visa applications as part of our comprehensive service."
        }
      ]
    },
    {
      category: "Tourist Visas",
      questions: [
        {
          question: "How far in advance should I apply for a tourist visa?",
          answer: "We recommend applying at least 4-6 weeks before your planned travel date. Some countries may require longer processing times, especially during peak seasons."
        },
        {
          question: "What if my tourist visa application is rejected?",
          answer: "If your application is rejected, we analyze the reasons and help you reapply with a stronger application. Our experience helps us address common rejection reasons effectively."
        },
        {
          question: "Can I extend my tourist visa while abroad?",
          answer: "Extension policies vary by country. Some allow extensions while others require you to exit and reapply. We provide guidance on extension procedures during your consultation."
        }
      ]
    },
    {
      category: "Immigration & PR",
      questions: [
        {
          question: "Which countries offer the best immigration opportunities?",
          answer: "Canada, Australia, New Zealand, and some European countries have active immigration programs. The best choice depends on your qualifications, experience, and personal preferences."
        },
        {
          question: "What is Express Entry (Canada)?",
          answer: "Express Entry is Canada's immigration system for skilled workers. It includes Federal Skilled Worker, Canadian Experience Class, and Federal Skilled Trades programs. We help you navigate this complex system."
        },
        {
          question: "How much does the immigration process cost?",
          answer: "Costs vary by country and program. This includes government fees, medical exams, language tests, and our service fees. We provide detailed cost breakdowns during consultation."
        }
      ]
    }
  ];

  const toggleItem = (index: number) => {
    setOpenItem(openItem === index ? null : index);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-16">
        {/* Header Section */}
        <section className="py-20 bg-gradient-to-br from-blue-900 via-indigo-900 to-purple-900">
          <div className="container mx-auto px-4">
            <div className="text-center text-white max-w-4xl mx-auto">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Frequently Asked <span className="bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">Questions</span>
              </h1>
              <p className="text-xl text-blue-100">
                Find answers to common questions about our visa and immigration services.
              </p>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4 max-w-4xl">
            {faqs.map((category, categoryIndex) => (
              <div key={categoryIndex} className="mb-12">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">{category.category}</h2>
                <div className="space-y-4">
                  {category.questions.map((faq, faqIndex) => {
                    const itemIndex = categoryIndex * 100 + faqIndex;
                    const isOpen = openItem === itemIndex;
                    
                    return (
                      <Card key={faqIndex} className="shadow-lg border-0">
                        <CardContent className="p-0">
                          <button
                            onClick={() => toggleItem(itemIndex)}
                            className="w-full p-6 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                          >
                            <span className="font-semibold text-gray-900 text-lg">{faq.question}</span>
                            {isOpen ? (
                              <ChevronUp className="h-5 w-5 text-gray-500 flex-shrink-0" />
                            ) : (
                              <ChevronDown className="h-5 w-5 text-gray-500 flex-shrink-0" />
                            )}
                          </button>
                          {isOpen && (
                            <div className="px-6 pb-6">
                              <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Still Have Questions?</h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Can't find the answer you're looking for? Our expert consultants are here to help with personalized guidance.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold px-8 py-4 rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-colors">
                Schedule Free Consultation
              </button>
              <button className="border-2 border-blue-600 text-blue-600 font-semibold px-8 py-4 rounded-lg hover:bg-blue-600 hover:text-white transition-colors">
                Contact Us Now
              </button>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </div>
  );
};

export default FAQ;
