
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { FloatingIcons } from "@/components/FloatingIcons";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plane, GraduationCap, Briefcase, Heart, MapPin, FileText, CheckCircle } from "lucide-react";

const ServicesPage = () => {
  const services = [
    {
      icon: Plane,
      title: "Tourist Visa",
      description: "Complete assistance for tourist and visit visas to explore the world",
      features: ["Document preparation", "Application filing", "Interview guidance", "Travel itinerary planning"],
      countries: ["USA", "UK", "Canada", "Australia", "Europe", "Dubai"]
    },
    {
      icon: GraduationCap,
      title: "Student Visa",
      description: "Expert guidance for study abroad programs and student visas",
      features: ["University selection", "Scholarship guidance", "Visa processing", "Pre-departure briefing"],
      countries: ["USA", "UK", "Canada", "Australia", "Germany", "New Zealand"]
    },
    {
      icon: Briefcase,
      title: "Work Visa",
      description: "Professional support for work permits and employment visas",
      features: ["Job placement", "Work permit", "Family visa assistance", "Skills assessment"],
      countries: ["Canada", "Australia", "UK", "USA", "Germany", "Dubai"]
    },
    {
      icon: Heart,
      title: "Family Visa",
      description: "Reunite with your loved ones through family sponsorship programs",
      features: ["Spouse visa", "Dependent visa", "Parent sponsorship", "Family reunion"],
      countries: ["USA", "UK", "Canada", "Australia", "Europe"]
    },
    {
      icon: MapPin,
      title: "Immigration",
      description: "Permanent residency and immigration consultation services",
      features: ["PR applications", "Citizenship guidance", "Investment visa", "Express entry"],
      countries: ["Canada", "Australia", "USA", "New Zealand", "UK"]
    },
    {
      icon: FileText,
      title: "Documentation",
      description: "Complete document verification and attestation services",
      features: ["Document verification", "Attestation services", "Translation", "Notarization"],
      countries: ["All Countries"]
    }
  ];

  return (
    <div className="min-h-screen bg-background relative">
      <FloatingIcons />
      <Navigation />
      <div className="pt-16 relative z-10">
        {/* Header Section */}
        <section className="py-20 bg-gradient-to-br from-blue-900 via-indigo-900 to-purple-900 relative overflow-hidden">
          {/* Animated Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-10 left-10 animate-spin-slow">
              <Plane className="h-12 w-12 text-white" />
            </div>
            <div className="absolute top-20 right-20 animate-bounce delay-300">
              <MapPin className="h-10 w-10 text-white" />
            </div>
            <div className="absolute bottom-20 left-1/4 animate-pulse delay-500">
              <GraduationCap className="h-14 w-14 text-white" />
            </div>
          </div>
          
          <div className="container mx-auto px-4 relative z-10">
            <div className="text-center text-white max-w-4xl mx-auto">
              <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
                Our <span className="bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">Services</span>
              </h1>
              <p className="text-xl text-blue-100 animate-fade-in delay-300">
                Comprehensive visa and immigration services tailored to your specific needs and dreams.
              </p>
            </div>
          </div>
        </section>

        {/* Services Grid */}
        <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service, index) => (
                <Card key={index} className="group hover:shadow-xl transition-all duration-500 hover:-translate-y-3 border-0 shadow-lg bg-white/80 backdrop-blur-sm animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                  <CardHeader className="text-center">
                    <div className="flex justify-center mb-4">
                      <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center group-hover:scale-125 group-hover:rotate-12 transition-all duration-500 shadow-lg">
                        <service.icon className="h-8 w-8 text-white animate-pulse" />
                      </div>
                    </div>
                    <CardTitle className="text-xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors duration-300">{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <CardDescription className="text-gray-600 text-base text-center group-hover:text-gray-800 transition-colors duration-300">
                      {service.description}
                    </CardDescription>
                    
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Our Services Include:</h4>
                      <ul className="space-y-2">
                        {service.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="text-sm text-gray-600 flex items-center group-hover:text-gray-800 transition-colors duration-300">
                            <CheckCircle className="w-4 h-4 text-green-500 mr-2 flex-shrink-0 group-hover:scale-110 transition-transform duration-300" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Popular Destinations:</h4>
                      <div className="flex flex-wrap gap-2">
                        {service.countries.map((country, countryIndex) => (
                          <span key={countryIndex} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full hover:bg-blue-200 transition-colors duration-300 cursor-default">
                            {country}
                          </span>
                        ))}
                      </div>
                    </div>

                    <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transform hover:scale-105 transition-all duration-300 shadow-lg">
                      Get Started
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Process Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-6 text-gray-900 animate-fade-in">Our Process</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto animate-fade-in delay-300">
                Simple, transparent, and efficient process to get your visa approved
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {[
                { step: "01", title: "Consultation", description: "Free initial consultation to understand your needs" },
                { step: "02", title: "Documentation", description: "Gather and prepare all required documents" },
                { step: "03", title: "Application", description: "Submit your application with expert guidance" },
                { step: "04", title: "Success", description: "Receive your visa and travel with confidence" }
              ].map((process, index) => (
                <div key={index} className="text-center group animate-fade-in" style={{ animationDelay: `${(index + 1) * 0.2}s` }}>
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4 group-hover:scale-110 group-hover:rotate-12 transition-all duration-300 shadow-lg">
                    {process.step}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors duration-300">{process.title}</h3>
                  <p className="text-gray-600 group-hover:text-gray-800 transition-colors duration-300">{process.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </div>
  );
};

export default ServicesPage;
